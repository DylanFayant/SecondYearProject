Ce dossier contient toutes les archives zippées des livrables
Accès en lecture: Tous les membres du projet
Accès en écriture: Le chef de projet (Dylan FAYANT)
