Ce dossier contient toute la documentation technique utile au projet et les documents de conception
Accès en lecture: Tous les membres du projet
Accès en écriture: Tous les membres du projet
