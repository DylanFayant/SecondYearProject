Ce dossier contient le planning du projet
Accès en lecture: Tous les membres du projet
Accès en écriture: Responsable du planning GANTT (Simon FOEX)
