# Second-Year Project
Bienvenue dans le repository de notre projet de seconde année "Client SNMP Android". Dans ce dossier vous pourrez trouver tout le contenu technique et de gestion de notre projet.

## Arbre du contenu
- doc (Dossier contenant les fichiers du premier semestre)
	- Documentation technique (Toute la doc concernant le projet)
	- Gestion des coûts (Rassemble les documents pour gérer les coûts du projet)
	- Livrables (Contient les archives des différents livrables)
	- Modalités projet (Tous les documents "administratifs" concernant le projet)
	- Planning (Contient le gantt)

## TODO list
21/10/16
- Envoyer le livrable à M.ROTTELEUR (cc. m. genthial, m. occello, m. massot)
Après
- Faire un "compte-rendu" de la réunion et l'envoyer à M. Genthial, Mme. Metge et M. Massot
- Prendre un rdv avec monsieur occello / monsieur jean pour se renseigner techniquement et conceptuellement
